// empty during dev
export const immutable = [];
export const prerendered = [];

export const assets = [
	{"path":".DS_Store"},
	{"path":"images/Altura.png"},
	{"path":"images/Chroniken.png"},
	{"path":"images/Ebene.png"},
	{"path":"images/Echo.png"},
	{"path":"images/Medusa.png"},
	{"path":"images/Nebel.png"},
	{"path":"images/placeholder.jpg"},
	{"path":"images/Schatten.png"},
	{"path":"images/Sternenwanderer.png"},
	{"path":"images/Traum.png"},
	{"path":"images/Waechter.png"},
	{"path":"robots.txt"}
];

export const routes = [
	{"id":"/","page":true,"endpoint":false},
	{"id":"/movies","page":true,"endpoint":false},
	{"id":"/movies/create","page":true,"endpoint":false},
	{"id":"/movies/[movie_id]","page":true,"endpoint":false}
];